package com.troxzy.trxchess.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView
import com.troxzy.trxchess.core.common.FeatureFlags

class OverlayService : Service(){
 private var window:WindowManager?=null;private var view:TextView?=null
 override fun onCreate(){super.onCreate();if(!FeatureFlags.overlay||!Settings.canDrawOverlays(this))return;window=getSystemService(WINDOW_SERVICE) as WindowManager;view=TextView(this).apply{text="TRX-CHESS  +0.00";setPadding(20,14,20,14);setTextColor(0xfff2f5f7.toInt());setBackgroundColor(0xdd101418.toInt());setOnTouchListener(DragListener(window!!,this))};val type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;val p=WindowManager.LayoutParams(WRAP_CONTENT,WRAP_CONTENT,type,FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP or Gravity.START;p.x=24;p.y=180;window?.addView(view,p)}
 override fun onDestroy(){view?.let{runCatching{window?.removeView(it)}};view=null;super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
 private class DragListener(private val wm:WindowManager,private val v:View):View.OnTouchListener{var sx=0f;var sy=0f;var ox=0;var oy=0;override fun onTouch(view:View,e:android.view.MotionEvent):Boolean{val p=v.layoutParams as WindowManager.LayoutParams;when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;return true};MotionEvent.ACTION_MOVE->{p.x=ox+(e.rawX-sx).toInt();p.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(v,p);return true}};return false}}
}
