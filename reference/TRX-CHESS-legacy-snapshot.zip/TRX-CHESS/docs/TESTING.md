# TRX-CHESS — TESTING

This document is intentionally kept close to the repository implementation. Update it together with any architectural change.
