package com.troxzy.trxchess.engine.uci

import com.troxzy.trxchess.chess.ChessPosition
import com.troxzy.trxchess.chess.Fen
import com.troxzy.trxchess.engine.api.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID
import kotlin.time.Duration.Companion.seconds

class UciEngine(private val native: suspend (String)->List<String>? = null, private val scope:CoroutineScope=CoroutineScope(SupervisorJob()+Dispatchers.Default)):ChessEngine {
    private val state=MutableStateFlow<EngineState>(EngineState.Uninitialized)
    private val analysis=MutableSharedFlow<EngineAnalysis>(extraBufferCapacity=64,onBufferOverflow=kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)
    private var current:ChessPosition?=null; private var config=EngineConfig(); private var job:Job?=null
    override suspend fun initialize(config:EngineConfig):EngineResult{state.value=EngineState.Initializing;this.config=config;delay(1);state.value=EngineState.Ready;return EngineResult.Ok}
    override suspend fun setPosition(position:ChessPosition):EngineResult{current=position;return EngineResult.Ok}
    override suspend fun startAnalysis(request:AnalysisRequest){stopAnalysis();val p=request.position;current=p;job=scope.launch{state.value=EngineState.Analyzing;val reqId=UUID.randomUUID().toString();val key=Fen.serialize(p).hashCode().toString(16);val lines=if(native!=null)parseNative(native.invoke(buildUciCommand(request))).lines else fallback(p,request);analysis.emit(EngineAnalysis(reqId,key,lines,System.currentTimeMillis()));state.value=EngineState.Ready}}
    override suspend fun stopAnalysis(){job?.cancelAndJoin();job=null;if(state.value==EngineState.Analyzing)state.value=EngineState.Ready}
    override suspend fun shutdown(){job?.cancel();job=null;state.value=EngineState.Shutdown;scope.cancel()}
    override fun observeState():Flow<EngineState>=state.asStateFlow()
    override fun observeAnalysis():Flow<EngineAnalysis>=analysis.asSharedFlow()
    private fun buildUciCommand(r:AnalysisRequest)=buildString{append("position fen ");append(Fen.serialize(r.position));append("\ngo ");when(val l=r.limit){is SearchLimit.Depth->append("depth ").append(l.value);is SearchLimit.TimeMs->append("movetime ").append(l.value);is SearchLimit.Nodes->append("nodes ").append(l.value)};append("\n")}
    private fun parseNative(lines:List<String>):EngineAnalysis{val infos=lines.mapNotNull(UciParser::parseInfo);val grouped=infos.groupBy{it.multiPv};val out=grouped.toSortedMap().values.map{xs->val x=xs.maxByOrNull{it.depth?:0}!!;EngineLine(x.multiPv,x.score?:Evaluation.Centipawn(0),x.depth?:0,x.nodes?:0,x.nps?:0,x.pv)};return EngineAnalysis(UUID.randomUUID().toString(),"native",out,System.currentTimeMillis())}
    private fun fallback(p:ChessPosition,r:AnalysisRequest):List<EngineLine>{val m=p.legalMoves().take(r.multiPv.coerceIn(1,8));return m.mapIndexed{i,move->EngineLine(i+1,Evaluation.Centipawn(0),1,0,0,listOf(move.toString()))}}
}
